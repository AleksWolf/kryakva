%TF.GenerationSoftware,KiCad,Pcbnew,10.0.6*%
%TF.CreationDate,2026-10-20T01:03:03+05:00*%
%TF.ProjectId,power_board,706f7765-725f-4626-9f61-72642e6b6963,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.6) date 2026-10-20 01:03:03*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.375000X-0.375000X-0.725000X0.375000X-0.725000X0.375000X0.725000X-0.375000X0.725000X0*%
%ADD11O,1.500000X2.200000*%
%ADD12RoundRect,0.750000X-0.750000X-3.500000X0.750000X-3.500000X0.750000X3.500000X-0.750000X3.500000X0*%
%ADD13C,2.200000*%
G04 APERTURE END LIST*
D10*
%TO.C,J5*%
X38000000Y-2099999D03*
D11*
X40000000Y-2099999D03*
X42000000Y-2099999D03*
%TD*%
D12*
%TO.C,BAT+*%
X48000000Y-5050000D03*
%TD*%
D10*
%TO.C,J3*%
X28000000Y-2099999D03*
D11*
X30000000Y-2099999D03*
X32000000Y-2099999D03*
%TD*%
D10*
%TO.C,J1*%
X23000000Y-6899999D03*
D11*
X25000000Y-6899999D03*
X27000000Y-6899999D03*
%TD*%
D10*
%TO.C,J2*%
X18000000Y-2099999D03*
D11*
X20000000Y-2099999D03*
X22000000Y-2099999D03*
%TD*%
D12*
%TO.C,BAT-*%
X2000000Y-5050000D03*
%TD*%
D13*
%TO.C,H*%
X15500000Y-8800000D03*
%TD*%
D10*
%TO.C,J4*%
X8000000Y-2099999D03*
D11*
X10000000Y-2099999D03*
X12000000Y-2099999D03*
%TD*%
D13*
%TO.C,H*%
X34500000Y-8800000D03*
%TD*%
M02*
